package com.careerai.studio;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

/** CareerAI Studio: responsive dark career dashboard. Java 17+, no third-party dependencies. */
public final class CareerAIPolished extends JFrame {
    private static final Color BG = new Color(10, 15, 29);
    private static final Color SIDEBAR = new Color(13, 21, 39);
    private static final Color PANEL = new Color(19, 29, 51);
    private static final Color PANEL_ALT = new Color(24, 37, 64);
    private static final Color BORDER = new Color(42, 59, 88);
    private static final Color TEXT = new Color(222, 233, 251);
    private static final Color MUTED = new Color(143, 162, 193);
    private static final Color CYAN = new Color(51, 220, 211);
    private static final Color BLUE = new Color(92, 132, 255);
    private static final Color PURPLE = new Color(178, 125, 255);
    private static final Color GREEN = new Color(78, 218, 163);
    private static final Color AMBER = new Color(255, 185, 91);

    private final CardLayout pageLayout = new CardLayout();
    private final JPanel pageHost = new JPanel(pageLayout);
    private final JPanel sidebarNav = new JPanel();
    private final JLabel pageEyebrow = label("CAREER WORKSPACE", 10, CYAN, true);
    private final JLabel pageTitle = label("Overview", 27, TEXT, true);
    private final JLabel pageSubtitle = label("Your career progress, all in one place.", 12, MUTED, false);
    private final JLabel status = label("Ready · Demo data is stored locally", 11, MUTED, false);
    private final JTextArea resumeText = new JTextArea();
    private final JTextField targetRole = field("Java Developer");
    private final JComboBox<String> location = new JComboBox<>(new String[]{"Any location", "Thane", "Mumbai", "Navi Mumbai", "Pune", "Remote"});
    private String activePage = "Overview";

    public CareerAIPolished() {
        super("CareerAI — Polished Dark Workspace");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 720));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        add(buildMain(), BorderLayout.CENTER);
        buildPages();
        navigate("Overview");
    }

    private JPanel buildSidebar() {
        JPanel side = new JPanel(new BorderLayout(0, 26));
        side.setBackground(SIDEBAR);
        side.setPreferredSize(new Dimension(252, 0));
        side.setBorder(new EmptyBorder(25, 16, 18, 16));

        JPanel brand = new JPanel(new BorderLayout(11, 0)); brand.setOpaque(false);
        BrandMark mark = new BrandMark(); mark.setPreferredSize(new Dimension(42, 42));
        JPanel brandWords = vertical();
        brandWords.add(label("CareerAI", 22, TEXT, true));
        brandWords.add(Box.createVerticalStrut(3));
        brandWords.add(label("STUDIO  /  2026", 9, CYAN, true));
        brand.add(mark, BorderLayout.WEST); brand.add(brandWords, BorderLayout.CENTER);
        side.add(brand, BorderLayout.NORTH);

        JPanel navWrap = new JPanel(new BorderLayout(0, 12)); navWrap.setOpaque(false);
        navWrap.add(label("YOUR WORKSPACE", 10, MUTED, true), BorderLayout.NORTH);
        sidebarNav.setOpaque(false); sidebarNav.setLayout(new GridLayout(0, 1, 0, 7));
        String[][] items = {{"◈", "Overview"}, {"▤", "Resume Studio"}, {"⌕", "Job Explorer"}, {"⌁", "Skill Roadmap"}, {"✧", "Learning Hub"}, {"◉", "My Profile"}};
        for (String[] item : items) {
            JButton b = navButton(item[0], item[1]);
            b.addActionListener(e -> navigate(item[1]));
            sidebarNav.add(b);
        }
        navWrap.add(sidebarNav, BorderLayout.CENTER); side.add(navWrap, BorderLayout.CENTER);

        JPanel bottom = vertical();
        JPanel tip = panel(PANEL_ALT, 15); tip.setLayout(new BoxLayout(tip, BoxLayout.Y_AXIS));
        tip.add(label("✦  A SMALL DAILY WIN", 10, CYAN, true)); tip.add(Box.createVerticalStrut(9));
        tip.add(label("Progress beats\nperfection.", 16, TEXT, true)); tip.add(Box.createVerticalStrut(7));
        tip.add(label("Build one skill. Improve one project. Repeat.", 11, MUTED, false));
        bottom.add(tip); bottom.add(Box.createVerticalStrut(15));
        bottom.add(label("●  OFFLINE DEMO", 10, GREEN, true)); bottom.add(Box.createVerticalStrut(5));
        bottom.add(label("No login or server needed", 10, MUTED, false));
        side.add(bottom, BorderLayout.SOUTH);
        return side;
    }

    private JPanel buildMain() {
        JPanel main = new JPanel(new BorderLayout(0, 20)); main.setBackground(BG);
        main.setBorder(new EmptyBorder(28, 32, 20, 32));
        JPanel header = new JPanel(new BorderLayout(16, 0)); header.setOpaque(false);
        JPanel titleBlock = vertical();
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.ENGLISH)).toUpperCase(Locale.ENGLISH);
        titleBlock.add(label(date + "   /   PERSONAL CAREER SPACE", 10, CYAN, true));
        titleBlock.add(Box.createVerticalStrut(7)); titleBlock.add(pageTitle);
        titleBlock.add(Box.createVerticalStrut(4)); titleBlock.add(pageSubtitle);
        header.add(titleBlock, BorderLayout.CENTER);
        JPanel profile = panel(PANEL, 13); profile.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 8));
        JLabel avatar = new JLabel("CA", SwingConstants.CENTER); avatar.setOpaque(true); avatar.setBackground(new Color(43, 68, 119)); avatar.setForeground(TEXT); avatar.setFont(new Font("SansSerif", Font.BOLD, 12)); avatar.setPreferredSize(new Dimension(38, 38)); avatar.setBorder(new LineBorder(new Color(74, 111, 185), 1, true));
        JPanel userWords = vertical(); userWords.add(label("Career starter", 12, TEXT, true)); userWords.add(Box.createVerticalStrut(3)); userWords.add(label("Java Developer", 10, MUTED, false));
        profile.add(avatar); profile.add(userWords); header.add(profile, BorderLayout.EAST);
        main.add(header, BorderLayout.NORTH);

        pageHost.setOpaque(false); pageHost.setBorder(new EmptyBorder(1, 1, 12, 1));
        JScrollPane scroll = new JScrollPane(pageHost); scroll.setBorder(null); scroll.setOpaque(false); scroll.getViewport().setOpaque(false);
        scroll.getVerticalScrollBar().setUnitIncrement(18); scroll.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        scroll.getVerticalScrollBar().setBackground(BG); scroll.getVerticalScrollBar().setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            protected void configureScrollBarColors() { thumbColor = new Color(58, 79, 116); trackColor = BG; }
            protected JButton createDecreaseButton(int o) { return zeroButton(); }
            protected JButton createIncreaseButton(int o) { return zeroButton(); }
            private JButton zeroButton() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0,0)); b.setMinimumSize(new Dimension(0,0)); b.setMaximumSize(new Dimension(0,0)); return b; }
        });
        main.add(scroll, BorderLayout.CENTER);
        JPanel footer = new JPanel(new BorderLayout()); footer.setOpaque(false);
        footer.add(status, BorderLayout.WEST); footer.add(label("CAREERAI STUDIO  •  BUILD YOUR NEXT MOVE", 9, new Color(95, 116, 151), true), BorderLayout.EAST);
        main.add(footer, BorderLayout.SOUTH);
        return main;
    }

    private void buildPages() {
        pageHost.add(overviewPage(), "Overview"); pageHost.add(resumePage(), "Resume Studio");
        pageHost.add(jobsPage(), "Job Explorer"); pageHost.add(skillsPage(), "Skill Roadmap");
        pageHost.add(learningPage(), "Learning Hub"); pageHost.add(profilePage(), "My Profile");
    }

    private JPanel overviewPage() {
        JPanel page = page(); page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        JPanel hero = panel(PANEL, 22); hero.setLayout(new BorderLayout(20, 0)); hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 194));
        JPanel heroCopy = vertical(); heroCopy.add(label("YOUR CAREER, IN FOCUS", 10, CYAN, true)); heroCopy.add(Box.createVerticalStrut(10));
        heroCopy.add(label("Make your next move count.", 24, TEXT, true)); heroCopy.add(Box.createVerticalStrut(8));
        heroCopy.add(label("A simple, focused workspace to prepare your resume, explore roles,\nand grow the skills employers are looking for.", 12, MUTED, false)); heroCopy.add(Box.createVerticalStrut(15));
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 9, 0)); actions.setOpaque(false); actions.add(actionButton("Review my resume  →", BLUE, () -> navigate("Resume Studio"))); actions.add(actionButton("Explore jobs", PANEL_ALT, () -> navigate("Job Explorer"))); heroCopy.add(actions);
        hero.add(heroCopy, BorderLayout.CENTER); ReadinessRing ring = new ReadinessRing(); ring.setPreferredSize(new Dimension(150, 128)); hero.add(ring, BorderLayout.EAST); page.add(hero); page.add(Box.createVerticalStrut(15));

        JPanel metrics = new JPanel(new GridLayout(1, 4, 12, 0)); metrics.setOpaque(false); metrics.setMaximumSize(new Dimension(Integer.MAX_VALUE, 126));
        metrics.add(metric("PROFILE READINESS", "72%", "A starting estimate", BLUE, "↗")); metrics.add(metric("ROLE EXAMPLES", "06", "Sample fresher roles", CYAN, "⌕")); metrics.add(metric("SKILL PRIORITIES", "04", "Focus areas to build", PURPLE, "⌁")); metrics.add(metric("LEARNING STREAK", "05 days", "Keep the momentum", AMBER, "✧"));
        page.add(metrics); page.add(Box.createVerticalStrut(15));

        JPanel two = new JPanel(new GridLayout(1, 2, 14, 0)); two.setOpaque(false); two.setMaximumSize(new Dimension(Integer.MAX_VALUE, 304));
        two.add(analyticsCard()); two.add(roadmapCard()); page.add(two); page.add(Box.createVerticalStrut(15));
        JPanel bottom = new JPanel(new GridLayout(1, 2, 14, 0)); bottom.setOpaque(false); bottom.setMaximumSize(new Dimension(Integer.MAX_VALUE, 208)); bottom.add(recommendationsCard()); bottom.add(activityCard()); page.add(bottom); page.add(Box.createVerticalStrut(10));
        return page;
    }

    private JPanel analyticsCard() {
        JPanel c = card(); c.setLayout(new BorderLayout(0, 8)); c.add(sectionTitle("Progress snapshot", "Illustrative weekly trend"), BorderLayout.NORTH);
        c.add(new TrendChart(), BorderLayout.CENTER); JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 13, 0)); legend.setOpaque(false);
        legend.add(dot(BLUE,"Profile")); legend.add(dot(CYAN,"Skills")); legend.add(dot(PURPLE,"Practice")); c.add(legend, BorderLayout.SOUTH); return c;
    }
    private JPanel roadmapCard() {
        JPanel c = card(); c.setLayout(new BorderLayout(0, 12)); c.add(sectionTitle("Your next 3 steps", "A practical plan for this week"), BorderLayout.NORTH);
        JPanel list = vertical(); list.add(roadStep("01", "Polish your resume", "Show projects, skills and outcomes", CYAN)); list.add(Box.createVerticalStrut(12));
        list.add(roadStep("02", "Build one portfolio project", "Document your Java + Spring Boot work", PURPLE)); list.add(Box.createVerticalStrut(12));
        list.add(roadStep("03", "Practise interview answers", "Explain your decisions out loud", AMBER)); c.add(list, BorderLayout.CENTER);
        c.add(actionButton("Open full roadmap  →", PANEL_ALT, () -> navigate("Skill Roadmap")), BorderLayout.SOUTH); return c;
    }
    private JPanel recommendationsCard() {
        JPanel c = card(); c.setLayout(new BorderLayout(0, 9)); c.add(sectionTitle("Recommended focus", "Based on a Java fresher track"), BorderLayout.NORTH);
        JPanel rows = vertical(); rows.add(recommendRow("Spring Boot fundamentals", "REST controllers · dependency injection", CYAN)); rows.add(Box.createVerticalStrut(9)); rows.add(recommendRow("SQL + problem solving", "Practise queries and core DSA", PURPLE)); c.add(rows, BorderLayout.CENTER); return c;
    }
    private JPanel activityCard() {
        JPanel c = card(); c.setLayout(new BorderLayout(0, 10)); c.add(sectionTitle("Quick actions", "Keep moving forward"), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(2,2,8,8)); grid.setOpaque(false);
        grid.add(actionButton("Resume review", new Color(38,64,104), () -> navigate("Resume Studio")));
        grid.add(actionButton("Find roles", new Color(28,74,83), () -> navigate("Job Explorer")));
        grid.add(actionButton("Skill roadmap", new Color(64,48,94), () -> navigate("Skill Roadmap")));
        grid.add(actionButton("Learning hub", new Color(83,61,37), () -> navigate("Learning Hub")));
        c.add(grid, BorderLayout.CENTER); return c;
    }

    private JPanel resumePage() {
        JPanel p = page(); p.setLayout(new BorderLayout(0,14));
        p.add(pageIntro("Resume Studio", "Paste your resume or load a plain-text file to review skill keywords."), BorderLayout.NORTH);
        JPanel editor = card(); editor.setLayout(new BorderLayout(0,12));
        JPanel top = new JPanel(new BorderLayout()); top.setOpaque(false); top.add(sectionTitle("Resume content", "Your text stays on this computer"), BorderLayout.WEST);
        top.add(actionButton("Load .TXT file", PANEL_ALT, this::loadResume), BorderLayout.EAST); editor.add(top, BorderLayout.NORTH);
        resumeText.setText("TANAYA JADHAV\nJava Developer | Fresher\n\nSUMMARY\nEntry-level Java developer interested in building reliable applications.\n\nTECHNICAL SKILLS\nJava, OOP, SQL, MySQL, Spring Boot, REST API, HTML, CSS, JavaScript, React, Git, JDBC, Collections, Data Structures\n\nPROJECTS\nCareerAI - Career dashboard using Java Swing\nGrocery application - React user interface\n\nEDUCATION\nAdd your degree, college and graduation year here.");
        resumeText.setFont(new Font("Monospaced", Font.PLAIN, 13)); resumeText.setForeground(TEXT); resumeText.setCaretColor(CYAN); resumeText.setSelectionColor(new Color(44,77,128)); resumeText.setBackground(new Color(11,19,36)); resumeText.setLineWrap(true); resumeText.setWrapStyleWord(true); resumeText.setBorder(new EmptyBorder(14,14,14,14));
        JScrollPane inputScroll = new JScrollPane(resumeText); inputScroll.setBorder(new LineBorder(BORDER,1,true)); inputScroll.getViewport().setBackground(new Color(11,19,36)); editor.add(inputScroll, BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0)); buttons.setOpaque(false); buttons.add(actionButton("Analyze resume  →", CYAN, this::analyzeResume)); buttons.add(actionButton("Clear text", PANEL_ALT, () -> {resumeText.setText(""); status.setText("Resume text cleared");})); editor.add(buttons, BorderLayout.SOUTH); p.add(editor, BorderLayout.CENTER); return p;
    }

    private JPanel jobsPage() {
        JPanel p = page(); p.setLayout(new BorderLayout(0,14)); p.add(pageIntro("Job Explorer", "Explore example roles and narrow them by target role and location."), BorderLayout.NORTH);
        JPanel content = vertical(); JPanel filters = card(); filters.setLayout(new BorderLayout(12,0));
        JPanel fields = new JPanel(new GridLayout(1,2,12,0)); fields.setOpaque(false); fields.add(fieldGroup("TARGET ROLE", targetRole));
        styleCombo(location); fields.add(fieldGroup("PREFERRED LOCATION", location)); filters.add(fields, BorderLayout.CENTER); filters.add(actionButton("Find sample matches", BLUE, this::findJobs), BorderLayout.EAST); content.add(filters); content.add(Box.createVerticalStrut(14));
        content.add(jobCard("Java Developer Intern", "Example role · Entry level", "Java  ·  OOP  ·  SQL  ·  Git", CYAN, "Build and maintain Java features with guidance from a development team.")); content.add(Box.createVerticalStrut(10));
        content.add(jobCard("Junior Backend Developer", "Example role · Fresher", "Spring Boot  ·  REST APIs  ·  MySQL", PURPLE, "Work on backend endpoints, data validation and database integration.")); content.add(Box.createVerticalStrut(10));
        content.add(jobCard("Associate Software Engineer", "Example role · Graduate", "DSA  ·  Java  ·  Problem solving", BLUE, "Collaborate with a team to implement, test and improve application features."));
        JScrollPane sc = new JScrollPane(content); sc.setBorder(null); sc.setOpaque(false); sc.getViewport().setOpaque(false); p.add(sc, BorderLayout.CENTER); return p;
    }

    private JPanel skillsPage() {
        JPanel p = page(); p.setLayout(new BorderLayout(0,14)); p.add(pageIntro("Skill Roadmap", "A practical sequence for a Java developer fresher. Adjust this plan to your current level."), BorderLayout.NORTH);
        JPanel list = vertical(); list.add(skillCard("01", "Core Java + OOP", "Classes, interfaces, collections, exceptions", 0.82, CYAN)); list.add(Box.createVerticalStrut(12));
        list.add(skillCard("02", "SQL + database basics", "Joins, grouping, indexes, JDBC", 0.64, BLUE)); list.add(Box.createVerticalStrut(12));
        list.add(skillCard("03", "Spring Boot + REST", "Dependency injection, controllers, validation", 0.46, PURPLE)); list.add(Box.createVerticalStrut(12));
        list.add(skillCard("04", "Testing + Git", "JUnit basics, debugging, branches and commits", 0.38, AMBER)); list.add(Box.createVerticalStrut(12));
        list.add(skillCard("05", "Interview practice", "DSA fundamentals and explaining projects", 0.32, GREEN)); p.add(list, BorderLayout.CENTER); return p;
    }

    private JPanel learningPage() {
        JPanel p = page(); p.setLayout(new BorderLayout(0,14)); p.add(pageIntro("Learning Hub", "A simple study routine. These are suggested topics, not external course links."), BorderLayout.NORTH);
        JPanel grid = new JPanel(new GridLayout(0,2,12,12)); grid.setOpaque(false);
        grid.add(learningCard("JAVA FOUNDATIONS", "OOP · Collections · Exceptions", "Revise one concept and write a small example.", CYAN, "Mark today's study", "Java foundations marked as studied"));
        grid.add(learningCard("DATABASE SKILLS", "SQL · Joins · JDBC", "Write five queries against a sample schema.", BLUE, "Mark today's study", "Database practice marked as studied"));
        grid.add(learningCard("SPRING BOOT", "REST · DI · Validation", "Create one endpoint and test the response.", PURPLE, "Mark today's study", "Spring Boot study marked as studied"));
        grid.add(learningCard("INTERVIEW PRACTICE", "DSA · Projects · Communication", "Answer one question aloud and refine it.", AMBER, "Mark today's practice", "Interview practice marked as complete"));
        p.add(grid, BorderLayout.CENTER); return p;
    }

    private JPanel profilePage() {
        JPanel p = page(); p.setLayout(new BorderLayout(0,14)); p.add(pageIntro("My Profile", "A local demo profile. Edit these fields to plan your next career step."), BorderLayout.NORTH);
        JPanel form = card(); form.setLayout(new GridBagLayout()); GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(8,8,8,8); g.fill = GridBagConstraints.HORIZONTAL; g.weightx=1; g.gridx=0; g.gridy=0;
        JTextField name = field("Career starter"); JTextField role = field("Java Developer"); JTextField stage = field("Fresher / Entry level"); JTextField goal = field("Prepare for Java developer interviews");
        form.add(fieldGroup("DISPLAY NAME",name),g); g.gridx=1; form.add(fieldGroup("TARGET ROLE",role),g); g.gridx=0;g.gridy++;form.add(fieldGroup("CURRENT STAGE",stage),g);g.gridx=1;form.add(fieldGroup("NEXT GOAL",goal),g);
        g.gridx=0;g.gridy++;g.gridwidth=2; g.weighty=1;g.anchor=GridBagConstraints.NORTHWEST;
        form.add(actionButton("Save profile locally", CYAN, () -> status.setText("Profile updated for this session · No server connection")),g);
        p.add(form,BorderLayout.CENTER); return p;
    }

    private JPanel pageIntro(String title, String subtitle) { JPanel p=vertical(); p.add(label(title.toUpperCase(Locale.ROOT),11,CYAN,true)); p.add(Box.createVerticalStrut(6)); p.add(label(subtitle,13,MUTED,false)); return p; }
    private JPanel metric(String title, String value, String note, Color accent, String glyph) {
        JPanel p=panel(PANEL,15); p.setLayout(new BorderLayout(0,8)); JPanel top=new JPanel(new BorderLayout());top.setOpaque(false);top.add(label(title,9,MUTED,true),BorderLayout.WEST);JLabel icon=label(glyph,17,accent,true);top.add(icon,BorderLayout.EAST);p.add(top,BorderLayout.NORTH);
        p.add(label(value,25,TEXT,true),BorderLayout.CENTER);p.add(label(note,10,accent,false),BorderLayout.SOUTH);return p;
    }
    private JPanel sectionTitle(String title,String subtitle){JPanel p=vertical();p.add(label(title,15,TEXT,true));p.add(Box.createVerticalStrut(4));p.add(label(subtitle,10,MUTED,false));return p;}
    private JPanel roadStep(String n,String title,String desc,Color accent){JPanel row=new JPanel(new BorderLayout(10,0));row.setOpaque(false);JLabel num=new JLabel(n,SwingConstants.CENTER);num.setOpaque(true);num.setBackground(new Color(31,48,78));num.setForeground(accent);num.setFont(new Font("SansSerif",Font.BOLD,12));num.setPreferredSize(new Dimension(38,38));num.setBorder(new LineBorder(BORDER,1,true));JPanel words=vertical();words.add(label(title,12,TEXT,true));words.add(Box.createVerticalStrut(4));words.add(label(desc,10,MUTED,false));row.add(num,BorderLayout.WEST);row.add(words,BorderLayout.CENTER);return row;}
    private JPanel recommendRow(String title,String sub,Color accent){JPanel r=new JPanel(new BorderLayout(9,0));r.setOpaque(false);JPanel mark=new JPanel();mark.setBackground(accent);mark.setPreferredSize(new Dimension(3,34));JPanel words=vertical();words.add(label(title,11,TEXT,true));words.add(Box.createVerticalStrut(4));words.add(label(sub,10,MUTED,false));r.add(mark,BorderLayout.WEST);r.add(words,BorderLayout.CENTER);return r;}
    private JPanel jobCard(String title,String type,String tags,Color accent,String description){JPanel c=card();c.setLayout(new BorderLayout(12,0));JPanel stripe=new JPanel();stripe.setBackground(accent);stripe.setPreferredSize(new Dimension(4,70));JPanel copy=vertical();copy.add(label(title,15,TEXT,true));copy.add(Box.createVerticalStrut(4));copy.add(label(type,10,accent,true));copy.add(Box.createVerticalStrut(7));copy.add(label(description,11,MUTED,false));copy.add(Box.createVerticalStrut(5));copy.add(label(tags,10,TEXT,false));c.add(stripe,BorderLayout.WEST);c.add(copy,BorderLayout.CENTER);c.add(actionButton("View details",PANEL_ALT,()->JOptionPane.showMessageDialog(this,title+"\n\n"+description+"\n\nThis is an example listing, not a live vacancy.","Example role",JOptionPane.INFORMATION_MESSAGE)),BorderLayout.EAST);return c;}
    private JPanel skillCard(String n,String title,String desc,double value,Color color){JPanel c=card();c.setLayout(new BorderLayout(12,0));JLabel num=new JLabel(n,SwingConstants.CENTER);num.setOpaque(true);num.setBackground(PANEL_ALT);num.setForeground(color);num.setFont(new Font("SansSerif",Font.BOLD,14));num.setPreferredSize(new Dimension(44,44));num.setBorder(new LineBorder(BORDER,1,true));JPanel copy=vertical();copy.add(label(title,14,TEXT,true));copy.add(Box.createVerticalStrut(5));copy.add(label(desc,11,MUTED,false));JProgressBar bar=new JProgressBar(0,100);bar.setValue((int)(value*100));bar.setStringPainted(true);bar.setString((int)(value*100)+"% self-assessed");bar.setForeground(color);bar.setBackground(new Color(34,47,70));bar.setBorderPainted(false);bar.setFont(new Font("SansSerif",Font.BOLD,10));bar.setPreferredSize(new Dimension(200,20));copy.add(Box.createVerticalStrut(10));copy.add(bar);c.add(num,BorderLayout.WEST);c.add(copy,BorderLayout.CENTER);return c;}
    private JPanel learningCard(String title,String tags,String desc,Color accent,String btn,String done){JPanel c=card();c.setLayout(new BorderLayout(0,10));c.add(label(title,10,accent,true),BorderLayout.NORTH);JPanel body=vertical();body.add(label(tags,13,TEXT,true));body.add(Box.createVerticalStrut(7));body.add(label(desc,11,MUTED,false));c.add(body,BorderLayout.CENTER);c.add(actionButton(btn,new Color(34,49,77),()->{status.setText(done);JOptionPane.showMessageDialog(this,done,"Learning Hub",JOptionPane.INFORMATION_MESSAGE);}),BorderLayout.SOUTH);return c;}
    private JPanel fieldGroup(String title,JComponent field){JPanel p=vertical();p.add(label(title,9,MUTED,true));p.add(Box.createVerticalStrut(7));field.setPreferredSize(new Dimension(190,40));p.add(field);return p;}
    private JPanel card(){JPanel p=new JPanel();p.setBackground(PANEL);p.setBorder(new CompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(17,18,17,18)));return p;}
    private JPanel panel(Color color,int padding){JPanel p=new JPanel();p.setBackground(color);p.setBorder(new CompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(padding,padding,padding,padding)));return p;}
    private JPanel page(){JPanel p=vertical();p.setOpaque(false);p.setBorder(new EmptyBorder(1,0,10,0));return p;}
    private JPanel vertical(){JPanel p=new JPanel();p.setOpaque(false);p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));return p;}
    private JLabel label(String s,int size,Color color,boolean bold){JLabel l=new JLabel(s);l.setForeground(color);l.setFont(new Font("Dialog",bold?Font.BOLD:Font.PLAIN,size+1));return l;}
    private JLabel dot(Color c,String text){JLabel l=label("●  "+text,10,MUTED,false);l.setIcon(null);return l;}
    private JButton navButton(String glyph,String text){JButton b=new JButton("  "+glyph+"     "+text);b.setHorizontalAlignment(SwingConstants.LEFT);b.setFont(new Font("Dialog",Font.BOLD,13));b.setForeground(MUTED);b.setBackground(SIDEBAR);b.setBorder(new CompoundBorder(new LineBorder(SIDEBAR,1,true),new EmptyBorder(12,10,12,8)));b.setFocusPainted(false);b.setOpaque(true);b.setContentAreaFilled(true);b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));b.setPreferredSize(new Dimension(200,44));b.setToolTipText(text);return b;}
    private JButton actionButton(String text,Color color,Runnable action){JButton b=new JButton(text);b.setFont(new Font("Dialog",Font.BOLD,13));b.setForeground((color.equals(CYAN)||color.equals(AMBER))?new Color(8,22,37):TEXT);b.setBackground(color);b.setBorder(new CompoundBorder(new LineBorder(brighter(color,0.18),1,true),new EmptyBorder(10,14,10,14)));b.setFocusPainted(false);b.setOpaque(true);b.setContentAreaFilled(true);b.setBorderPainted(true);b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));b.setRolloverEnabled(true);b.addMouseListener(new MouseAdapter(){public void mouseEntered(MouseEvent e){b.setBackground(brighter(color,0.10));}public void mouseExited(MouseEvent e){b.setBackground(color);}});b.addActionListener(e->action.run());return b;}
    private static Color brighter(Color c,double factor){return new Color((int)Math.min(255,c.getRed()+(255-c.getRed())*factor),(int)Math.min(255,c.getGreen()+(255-c.getGreen())*factor),(int)Math.min(255,c.getBlue()+(255-c.getBlue())*factor));}
    private static JTextField field(String text){JTextField f=new JTextField(text);f.setFont(new Font("Dialog",Font.PLAIN,13));f.setForeground(TEXT);f.setCaretColor(CYAN);f.setBackground(new Color(11,19,36));f.setBorder(new CompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(9,10,9,10)));return f;}
    private void styleCombo(JComboBox<String> combo){combo.setFont(new Font("Dialog",Font.PLAIN,13));combo.setForeground(TEXT);combo.setBackground(new Color(11,19,36));combo.setBorder(new LineBorder(BORDER,1,true));combo.setFocusable(false);}

    private void navigate(String name){activePage=name;pageLayout.show(pageHost,name);switch(name){case "Overview"->{pageTitle.setText("Overview");pageSubtitle.setText("Your career progress, all in one place.");}case "Resume Studio"->{pageTitle.setText("Resume Studio");pageSubtitle.setText("Make your experience easy for recruiters to understand.");}case "Job Explorer"->{pageTitle.setText("Job Explorer");pageSubtitle.setText("Discover the kinds of entry-level roles to target.");}case "Skill Roadmap"->{pageTitle.setText("Skill Roadmap");pageSubtitle.setText("Focus your learning on the next useful skill.");}case "Learning Hub"->{pageTitle.setText("Learning Hub");pageSubtitle.setText("Turn your goals into a steady learning habit.");}default->{pageTitle.setText("My Profile");pageSubtitle.setText("Keep your target role and next goal clear.");}}
        for(Component comp:sidebarNav.getComponents())if(comp instanceof JButton b){boolean active=b.getText().endsWith(name);b.setBackground(active?new Color(31,53,88):SIDEBAR);b.setForeground(active?CYAN:MUTED);b.setBorder(new CompoundBorder(active?new MatteBorder(0,3,0,0,CYAN):new LineBorder(SIDEBAR,1,true),new EmptyBorder(12,10,12,8)));}status.setText("Viewing "+name+"  ·  Local demo mode");}
    private void loadResume(){JFileChooser chooser=new JFileChooser();chooser.setDialogTitle("Choose a plain-text resume");chooser.setFileFilter(new FileNameExtensionFilter("Text resume (*.txt)","txt"));if(chooser.showOpenDialog(this)==JFileChooser.APPROVE_OPTION){try{resumeText.setText(Files.readString(chooser.getSelectedFile().toPath(),StandardCharsets.UTF_8));status.setText("Loaded "+chooser.getSelectedFile().getName());}catch(IOException ex){JOptionPane.showMessageDialog(this,"Could not read the selected file.","File error",JOptionPane.ERROR_MESSAGE);}}}
    private void analyzeResume(){String content=resumeText.getText().toLowerCase(Locale.ROOT).trim();if(content.isEmpty()){JOptionPane.showMessageDialog(this,"Paste your resume or load a .txt file first.","Resume needed",JOptionPane.INFORMATION_MESSAGE);return;}String[] terms={"java","oop","sql","spring boot","rest api","html","css","javascript","react","git","mysql","jdbc","servlet","communication","problem solving","collections","data structures"};List<String> found=new ArrayList<>(),missing=new ArrayList<>();for(String t:terms)(content.contains(t)?found:missing).add(t);int score=(int)Math.round(found.size()*100.0/terms.length);JTextArea report=new JTextArea("RESUME KEYWORD REVIEW\n\nKeyword coverage: "+score+"%\n\nDETECTED ("+found.size()+")\n"+String.join(", ",found)+"\n\nPOTENTIAL SKILLS TO REVIEW\n"+String.join(", ",missing)+"\n\nSUGGESTIONS\n• Add 2–3 clear project bullet points.\n• Mention the technologies you used and what you built.\n• Include outcomes or measurable results where possible.\n\nThis is a local keyword check, not an AI hiring score.");report.setEditable(false);report.setLineWrap(true);report.setWrapStyleWord(true);report.setBackground(PANEL);report.setForeground(TEXT);report.setCaretColor(CYAN);report.setFont(new Font("Monospaced",Font.PLAIN,12));report.setBorder(new EmptyBorder(16,16,16,16));JScrollPane scroll=new JScrollPane(report);scroll.setPreferredSize(new Dimension(530,390));JOptionPane.showMessageDialog(this,scroll,"Resume review",JOptionPane.INFORMATION_MESSAGE);status.setText("Resume reviewed · "+found.size()+" skill terms detected · "+score+"% keyword coverage");}
    private void findJobs(){String role=targetRole.getText().trim();if(role.isEmpty()){JOptionPane.showMessageDialog(this,"Enter a target role first.","Target role needed",JOptionPane.INFORMATION_MESSAGE);return;}JOptionPane.showMessageDialog(this,"Example matches for: "+role+"\nPreferred location: "+location.getSelectedItem()+"\n\nThese are sample role categories, not live vacancies. Use company career pages to verify current openings.","Sample job matches",JOptionPane.INFORMATION_MESSAGE);status.setText("Sample role search prepared for "+role);}

    private static JButton zeroButton(){JButton b=new JButton();b.setPreferredSize(new Dimension(0,0));return b;}
    private static final class BrandMark extends JPanel{BrandMark(){setOpaque(false);}protected void paintComponent(Graphics g){super.paintComponent(g);Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);x.setPaint(new GradientPaint(0,0,BLUE,getWidth(),getHeight(),CYAN));x.fillRoundRect(0,0,getWidth(),getHeight(),14,14);x.setColor(new Color(9,19,36));x.setFont(new Font("SansSerif",Font.BOLD,24));x.drawString("✦",10,30);x.dispose();}}
    private static final class ReadinessRing extends JPanel{ReadinessRing(){setOpaque(false);}protected void paintComponent(Graphics g){super.paintComponent(g);Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);int d=102,xx=(getWidth()-d)/2,yy=(getHeight()-d)/2;x.setStroke(new BasicStroke(9,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));x.setColor(BORDER);x.drawArc(xx,yy,d,d,90,360);x.setPaint(new GradientPaint(xx,yy,BLUE,xx+d,yy+d,CYAN));x.drawArc(xx,yy,d,d,90,-259);x.setFont(new Font("SansSerif",Font.BOLD,24));x.setColor(TEXT);String s="72%";FontMetrics fm=x.getFontMetrics();x.drawString(s,xx+(d-fm.stringWidth(s))/2,yy+55);x.setFont(new Font("SansSerif",Font.BOLD,9));x.setColor(MUTED);s="STARTING POINT";fm=x.getFontMetrics();x.drawString(s,xx+(d-fm.stringWidth(s))/2,yy+72);x.dispose();}}
    private static final class TrendChart extends JPanel{TrendChart(){setOpaque(false);setPreferredSize(new Dimension(280,135));}protected void paintComponent(Graphics g){super.paintComponent(g);Graphics2D x=(Graphics2D)g.create();x.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);int l=32,r=getWidth()-10,t=10,b=getHeight()-24;x.setFont(new Font("SansSerif",Font.PLAIN,9));for(int i=0;i<4;i++){int y=t+(b-t)*i/3;x.setColor(BORDER);x.drawLine(l,y,r,y);x.setColor(MUTED);x.drawString((90-i*25)+"",2,y+3);}draw(x,new int[]{38,44,42,57,61,68,72},l,r,t,b,BLUE);draw(x,new int[]{26,33,39,42,49,57,64},l,r,t,b,CYAN);draw(x,new int[]{18,22,31,30,41,46,55},l,r,t,b,PURPLE);String[] d={"M","T","W","T","F","S","S"};for(int i=0;i<7;i++){x.setColor(MUTED);x.drawString(d[i],l+(r-l)*i/6-3,b+15);}x.dispose();}private void draw(Graphics2D x,int[] a,int l,int r,int t,int b,Color c){Path2D path=new Path2D.Double();for(int i=0;i<a.length;i++){double px=l+(r-l)*i/(double)(a.length-1),py=b-(b-t)*(a[i]-10)/80.0;if(i==0)path.moveTo(px,py);else path.lineTo(px,py);}x.setColor(c);x.setStroke(new BasicStroke(2.4f,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));x.draw(path);for(int i=0;i<a.length;i++){int px=l+(r-l)*i/(a.length-1),py=b-(int)((b-t)*(a[i]-10)/80.0);x.fillOval(px-3,py-3,6,6);}}}

    private static void installDarkTheme(){
        try{UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());}catch(Exception ignored){}
        UIManager.put("control",PANEL);UIManager.put("info",PANEL);UIManager.put("nimbusBase",PANEL);UIManager.put("nimbusBlueGrey",PANEL_ALT);UIManager.put("nimbusLightBackground",BG);UIManager.put("text",TEXT);UIManager.put("Panel.background",BG);UIManager.put("OptionPane.background",PANEL);UIManager.put("OptionPane.messageForeground",TEXT);UIManager.put("OptionPane.foreground",TEXT);UIManager.put("Button.background",PANEL_ALT);UIManager.put("Button.foreground",TEXT);UIManager.put("TextField.background",new Color(11,19,36));UIManager.put("TextField.foreground",TEXT);UIManager.put("TextArea.background",new Color(11,19,36));UIManager.put("TextArea.foreground",TEXT);UIManager.put("ComboBox.background",new Color(11,19,36));UIManager.put("ComboBox.foreground",TEXT);UIManager.put("ComboBox.selectionBackground",new Color(42,72,117));UIManager.put("ComboBox.selectionForeground",TEXT);UIManager.put("ScrollPane.background",BG);UIManager.put("Viewport.background",BG);UIManager.put("ProgressBar.background",new Color(34,47,70));UIManager.put("ProgressBar.foreground",CYAN);UIManager.put("FileChooser.background",PANEL);UIManager.put("FileChooser.foreground",TEXT);UIManager.put("List.background",PANEL);UIManager.put("List.foreground",TEXT);UIManager.put("List.selectionBackground",new Color(42,72,117));UIManager.put("List.selectionForeground",TEXT);UIManager.put("ToolTip.background",PANEL_ALT);UIManager.put("ToolTip.foreground",TEXT);
    }
    public static void main(String[] args){installDarkTheme();SwingUtilities.invokeLater(()->new CareerAIPolished().setVisible(true));}
}
